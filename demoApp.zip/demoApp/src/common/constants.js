export const DEFAULT_PER_PAGE = 10;
export const DEFAULT_PAGE = 1;
export const BCRYPT_SALT = 12;
export const JWT = {
  SECRET: "influncerappandbusinessownerapp",
  EXPIRES_IN: "1 YEAR",
};
