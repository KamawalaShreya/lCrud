import express from "express";
const router = express.Router();
import ProductRoutes from "../src/product/product.routes";
import AuthRoutes from "../src/auth/auth.routes";
import authnticateUser from "../src/common/middleware/authnticate-user";
router.use("/products", authnticateUser,ProductRoutes);
router.use("/auth", AuthRoutes);

export default router;
